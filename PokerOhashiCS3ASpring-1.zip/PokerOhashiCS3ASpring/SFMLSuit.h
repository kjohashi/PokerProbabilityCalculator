//
// Created by Kota Ohashi on 5/26/24.
//
#ifndef POKER_SFMLSUIT_H
#define POKER_SFMLSUIT_H
#include <SFML/Graphics.hpp>
#include "CardVariables.h"


#endif //POKER_SFMLSUIT_H
